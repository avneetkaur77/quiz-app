package com.example.quizapp

object QuestionAnswer {

    var question = arrayOf(
        "Which one is not a fruit?",
        "How many colors are there in a rainbow ?",
        "Which one is the capital of India?",

    )
    var choices = arrayOf(
            arrayOf("Apple", "Banana", "Peach", "Peas"),
            arrayOf ("one", "seven", "nine", "two"),
            arrayOf("Delhi","Mumbai","Kolkata","Pune")
    )
    var correctAnswers = arrayOf(
        "Peas",
        "seven",
        "Delhi"
    )
}