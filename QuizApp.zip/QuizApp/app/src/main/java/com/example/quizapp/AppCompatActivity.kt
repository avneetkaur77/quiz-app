package com.example.quizapp

open class AppCompatActivity {

}
