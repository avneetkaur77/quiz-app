package com.example.quizapp

import android.content.DialogInterface
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog

class MainActivity : AppCompatActivity(),View.OnClickListener {


  lateinit  var totalQuestionTextView:TextView
    lateinit  var questionTextView:TextView
    lateinit  var ansa:TextView
    lateinit  var ansb:TextView
    lateinit  var ansc:TextView
    lateinit  var ansd:TextView
    lateinit var submitBtn:Button
    var score = 0
    var totalQuestion:Int = QuestionAnswer.question.size
    var currentQuestionIndex = 0
    var selectedAnswer = ""
    fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        totalQuestionTextView = findViewById(R.id.total_question)
        questionTextView = findViewById(R.id.question)
        ansa = findViewById(R.id.ans_a)
        ansb = findViewById(R.id.ans_b)
        ansc = findViewById(R.id.ans_c)
        ansd = findViewById(R.id.ans_d)
        submitBtn = findViewById(R.id.submit_btn)
        ansa.setOnClickListener(this)
        ansb.setOnClickListener(this)
        ansc.setOnClickListener(this)
        ansd.setOnClickListener(this)
        submitBtn.setOnClickListener(this)
        totalQuestionTextView.text= "Total Questions :$totalQuestion"
        loadNewQuestion()
    }

    private fun findViewById(ansC: Int): TextView {

    }

    private fun setContentView(activityMain: Int) {

    }


    override fun onClick(view: View?) {
      ansa.setBackgroundColor(Color.WHITE)
        ansb.setBackgroundColor(Color.WHITE)
        ansc.setBackgroundColor(Color.WHITE)
        ansd.setBackgroundColor(Color.WHITE)
        ansa.setTextColor(Color.BLACK)
        ansb.setTextColor(Color.BLACK)
        ansc.setTextColor(Color.BLACK)
        ansd.setTextColor(Color.BLACK)
        val clickedButton = view as Button
        if (clickedButton.id == R.id.submit_btn) {
            if (selectedAnswer == QuestionAnswer.correctAnswers[currentQuestionIndex]) {
                score++
            }
            currentQuestionIndex++
            loadNewQuestion()
        }else{
            selectedAnswer = clickedButton.text.toString()
            clickedButton.setBackgroundColor(Color.RED)
            clickedButton.setTextColor(Color.WHITE)

        }
    }
    private fun loadNewQuestion() {
       if (currentQuestionIndex == totalQuestion){
           finishQuiz()
           return
       }
        questionTextView.text = QuestionAnswer.question[currentQuestionIndex]
        ansa.text = QuestionAnswer.choices[currentQuestionIndex][0]
        ansb.text = QuestionAnswer.choices[currentQuestionIndex][1]
        ansc.text = QuestionAnswer.choices[currentQuestionIndex][2]
        ansd.text = QuestionAnswer.choices[currentQuestionIndex][3]
    }

    private fun finishQuiz() {
       var passStatus = ""
        passStatus = if (score>totalQuestion*0.60){
            "Passed"
        }else{
            "Failed"
        }
        AlertDialog.Builder(this)
            .setTitle("PassStatus")
            .setMessage("Score is $score out of $totalQuestion")
            .setPositiveButton("Restart"){ dialogInterface:DialogInterface,i:Int ->
                restartQuiz()
    }
            .setCancelable(false)
            .show()
}

    private fun restartQuiz() {
        score = 0
        currentQuestionIndex =0
        loadNewQuestion()
    }
}

private fun Any.onCreate(savedInstanceState: Bundle?) {

}
